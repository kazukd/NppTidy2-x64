var annotated =
[
    [ "_TidyAllocator", "struct__TidyAllocator.html", "struct__TidyAllocator" ],
    [ "_TidyAllocatorVtbl", "struct__TidyAllocatorVtbl.html", "struct__TidyAllocatorVtbl" ],
    [ "_TidyBuffer", "struct__TidyBuffer.html", "struct__TidyBuffer" ],
    [ "_TidyInputSource", "struct__TidyInputSource.html", "struct__TidyInputSource" ],
    [ "_TidyOutputSink", "struct__TidyOutputSink.html", "struct__TidyOutputSink" ],
    [ "TidyAttr", "structTidyAttr.html", null ],
    [ "TidyDoc", "structTidyDoc.html", null ],
    [ "TidyNode", "structTidyNode.html", null ],
    [ "TidyOption", "structTidyOption.html", null ]
];