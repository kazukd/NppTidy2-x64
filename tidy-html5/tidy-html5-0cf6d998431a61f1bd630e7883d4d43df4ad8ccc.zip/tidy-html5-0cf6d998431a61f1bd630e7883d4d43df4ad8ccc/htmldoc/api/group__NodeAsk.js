var group__NodeAsk =
[
    [ "Deprecated node interrogation per TagId", "group__NodeIsElementName.html", "group__NodeIsElementName" ],
    [ "tidyNodeGetType", "group__NodeAsk.html#gaa9786b1ce44061e2811d1ecbcd76d318", null ],
    [ "tidyNodeGetName", "group__NodeAsk.html#ga5ea4ecef06555a58f942b2c500722156", null ],
    [ "tidyNodeIsText", "group__NodeAsk.html#ga446c2a5ed55a75685074585f007b52c5", null ],
    [ "tidyNodeIsProp", "group__NodeAsk.html#ga2eb2b4a0ee75c74215de9859467d17f1", null ],
    [ "tidyNodeIsHeader", "group__NodeAsk.html#ga69c929ff5987273560e683e44b2515eb", null ],
    [ "tidyNodeHasText", "group__NodeAsk.html#ga4abc910dd180773665c6e2e4e30ea2d7", null ],
    [ "tidyNodeGetText", "group__NodeAsk.html#ga174176952045d3a79500451eae0322d6", null ],
    [ "tidyNodeGetValue", "group__NodeAsk.html#ga775c446f1fd1ffa25eb688af6c56853c", null ],
    [ "tidyNodeGetId", "group__NodeAsk.html#ga30307d5b9937c7f0aad1f37d7cf7848c", null ],
    [ "tidyNodeLine", "group__NodeAsk.html#ga98658b8c02e0d2000a6c7da5d916ced4", null ],
    [ "tidyNodeColumn", "group__NodeAsk.html#ga00fb1f74d89419ad97f345660cd8876f", null ]
];