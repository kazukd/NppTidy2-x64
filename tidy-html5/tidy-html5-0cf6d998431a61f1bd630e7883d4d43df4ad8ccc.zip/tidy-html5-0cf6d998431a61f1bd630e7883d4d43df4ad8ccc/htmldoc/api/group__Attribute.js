var group__Attribute =
[
    [ "Deprecated attribute interrogation per AttrId", "group__AttrIsAttributeName.html", "group__AttrIsAttributeName" ],
    [ "tidyAttrGetId", "group__Attribute.html#ga42c5074e590ed76a7a641dfd179471d9", null ],
    [ "tidyAttrIsEvent", "group__Attribute.html#ga1e4d8ec29e240a6415b2caa7fff2b502", null ],
    [ "tidyAttrIsProp", "group__Attribute.html#ga9f52a0de76388df02294718c573911bd", null ]
];