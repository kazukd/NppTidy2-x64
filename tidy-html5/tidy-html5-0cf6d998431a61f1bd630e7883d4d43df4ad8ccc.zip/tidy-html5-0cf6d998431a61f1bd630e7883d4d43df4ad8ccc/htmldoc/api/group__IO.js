var group__IO =
[
    [ "_TidyInputSource", "struct__TidyInputSource.html", null ],
    [ "_TidyOutputSink", "struct__TidyOutputSink.html", null ],
    [ "EndOfStream", "group__IO.html#ga9a078b706ec6f37cce40958f6f68585a", null ],
    [ "TidyGetByteFunc", "group__IO.html#ga6951f79d4b50288e96a3896ab01393d6", null ],
    [ "TidyUngetByteFunc", "group__IO.html#ga298b882c5fc7cc969ef58fb187bdd371", null ],
    [ "TidyEOFFunc", "group__IO.html#ga9f8e1bb4c4740ffb399ec424594c4972", null ],
    [ "TidyInputSource", "group__IO.html#ga86fcc3c86bd63b26a559938bc38d34bb", null ],
    [ "TidyPutByteFunc", "group__IO.html#ga63bcce5aa5f52e4e2e22aedd750b8bbc", null ],
    [ "TidyOutputSink", "group__IO.html#ga6bdd15de48364d2b5dbf2141109d3f98", null ],
    [ "TidyReportFilter", "group__IO.html#ga29c5bee28b95924a97ea4fbb81668c5e", null ],
    [ "tidyInitSource", "group__IO.html#gab446af273e331cb0440dd01b6990d2d0", null ],
    [ "tidyGetByte", "group__IO.html#gadba396ffec9f29b27d73a23264dcfa0b", null ],
    [ "tidyUngetByte", "group__IO.html#ga0c8d46de315cabb0ac7d2cf01ca183d7", null ],
    [ "tidyIsEOF", "group__IO.html#ga399df5ba17614205964a665f7b1726a6", null ],
    [ "tidyInitSink", "group__IO.html#ga7e93289be3a7253cdf99a96285e6a2d4", null ],
    [ "tidyPutByte", "group__IO.html#ga2a34772782d7b786e37012fce4cd2425", null ],
    [ "tidySetReportFilter", "group__IO.html#ga51e02523601388bb83c2555b995e68b0", null ],
    [ "tidySetErrorFile", "group__IO.html#ga669758031bbd5d4ba957b19e77229c8b", null ],
    [ "tidySetErrorBuffer", "group__IO.html#ga5e5cffe93edf4bea0d3214be70d6f77b", null ],
    [ "tidySetErrorSink", "group__IO.html#gad47c75f3af85e7927e7ac18918ec6363", null ]
];