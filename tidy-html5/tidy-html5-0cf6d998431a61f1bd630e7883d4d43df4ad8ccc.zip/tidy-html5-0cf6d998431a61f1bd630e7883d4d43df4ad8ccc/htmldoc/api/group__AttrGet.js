var group__AttrGet =
[
    [ "Deprecated attribute retrieval per AttrId", "group__AttrGetAttributeName.html", "group__AttrGetAttributeName" ],
    [ "tidyAttrGetById", "group__AttrGet.html#ga5391e01ca5a2b497a7c044a25080468e", null ]
];