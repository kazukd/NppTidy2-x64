var struct__TidyBuffer =
[
    [ "allocator", "struct__TidyBuffer.html#ab6655c52ed81490e8016976a4810a330", null ],
    [ "bp", "struct__TidyBuffer.html#a2b1c3814410eefbe2168b248485eea91", null ],
    [ "size", "struct__TidyBuffer.html#a227728492f6266dec940bcc541046cd9", null ],
    [ "allocated", "struct__TidyBuffer.html#a523a1f5f2a1b0333d70b9d8a5a52de13", null ],
    [ "next", "struct__TidyBuffer.html#af607eaeb44ae6d8f2371e1e05b016caf", null ]
];