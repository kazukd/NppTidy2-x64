var struct__TidyAllocator =
[
    [ "vtbl", "struct__TidyAllocator.html#a2113f1c06a3cfe4cbdf9212a47e6938b", null ]
];