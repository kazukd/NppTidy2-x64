var buffio_8h =
[
    [ "tidyBufInit", "buffio_8h.html#a3cf251a96f69f05495744af6c9d0339b", null ],
    [ "tidyBufInitWithAllocator", "buffio_8h.html#aff43ddd9fc78532617d88db55b164f5e", null ],
    [ "tidyBufAlloc", "buffio_8h.html#a896654bd99113bfe5e86b924836aacc3", null ],
    [ "tidyBufAllocWithAllocator", "buffio_8h.html#a57c832b4ddbc19a329a5ab9936eb5826", null ],
    [ "tidyBufCheckAlloc", "buffio_8h.html#a7a66ba1f574955d1fc1de57476e849f2", null ],
    [ "tidyBufFree", "buffio_8h.html#a65aae9ae4b499e62038700f4792849fc", null ],
    [ "tidyBufClear", "buffio_8h.html#aa94e59f613a495b17e90c1c4778c3911", null ],
    [ "tidyBufAttach", "buffio_8h.html#ac5909e78d98583cb245dd2004469bb93", null ],
    [ "tidyBufDetach", "buffio_8h.html#a8da2bf473b14e6bdd5cd40fc47c29903", null ],
    [ "tidyBufAppend", "buffio_8h.html#ad59b32f81789b634758274f34be4d25b", null ],
    [ "tidyBufPutByte", "buffio_8h.html#af48af586ada5ff264501fe9ef4c67dd1", null ],
    [ "tidyBufPopByte", "buffio_8h.html#af8b1e8fbe3c29d08250794d7e4925ea6", null ],
    [ "tidyBufGetByte", "buffio_8h.html#a5a2e0c47b4b14b5beb17ac982fa21eeb", null ],
    [ "tidyBufEndOfInput", "buffio_8h.html#a7e7d8e58623c8bde00d66141edb2cae0", null ],
    [ "tidyBufUngetByte", "buffio_8h.html#a1d1f2039b769381d418ac1187b50b292", null ],
    [ "tidyInitInputBuffer", "buffio_8h.html#a73da3182aea89939af1d98504a3b2df0", null ],
    [ "tidyInitOutputBuffer", "buffio_8h.html#a882a92590a9e6ecce16d5b8e8db19fbb", null ]
];