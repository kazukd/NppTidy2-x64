var group__Opaque =
[
    [ "TidyDoc", "structTidyDoc.html", null ],
    [ "TidyOption", "structTidyOption.html", null ],
    [ "TidyNode", "structTidyNode.html", null ],
    [ "TidyAttr", "structTidyAttr.html", null ],
    [ "opaque_type", "group__Opaque.html#ga1b209c260854e89f73101c18fe835516", null ],
    [ "opaque_type", "group__Opaque.html#gafdaa7208b82ae763fbccb646035f9391", null ],
    [ "opaque_type", "group__Opaque.html#gaa8d1f990e71bf7d6bc1b17974b7788a4", null ],
    [ "opaque_type", "group__Opaque.html#ga236c416d715827e6db5691ce66415c2f", null ]
];