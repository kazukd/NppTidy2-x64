var group__Save =
[
    [ "tidySaveFile", "group__Save.html#ga19ee6e2ee0e719a97cff443ebb19ae44", null ],
    [ "tidySaveStdout", "group__Save.html#ga6638d1800ee63fc6bea19bc2bf582be2", null ],
    [ "tidySaveBuffer", "group__Save.html#ga7e8642262c8c4d34cf7cc426647d29f0", null ],
    [ "tidySaveString", "group__Save.html#gaf684fefd3e42f459cf0a4ebe937ce12b", null ],
    [ "tidySaveSink", "group__Save.html#gaea985b28470453d0218092b137f71e77", null ]
];