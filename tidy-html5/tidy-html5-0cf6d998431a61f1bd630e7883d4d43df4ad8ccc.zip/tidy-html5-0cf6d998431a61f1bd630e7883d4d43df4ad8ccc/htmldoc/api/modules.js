var modules =
[
    [ "Opaque Types", "group__Opaque.html", "group__Opaque" ],
    [ "Memory Allocation", "group__Memory.html", "group__Memory" ],
    [ "Basic Operations", "group__Basic.html", "group__Basic" ],
    [ "Configuration Options", "group__Configuration.html", "group__Configuration" ],
    [ "I/O and Messages", "group__IO.html", "group__IO" ],
    [ "Document Parse", "group__Parse.html", "group__Parse" ],
    [ "Diagnostics and Repair", "group__Clean.html", "group__Clean" ],
    [ "Document Save Functions", "group__Save.html", "group__Save" ],
    [ "Document Tree", "group__Tree.html", "group__Tree" ],
    [ "Node Interrogation", "group__NodeAsk.html", "group__NodeAsk" ],
    [ "Attribute Interrogation", "group__Attribute.html", "group__Attribute" ],
    [ "Attribute Retrieval", "group__AttrGet.html", "group__AttrGet" ]
];