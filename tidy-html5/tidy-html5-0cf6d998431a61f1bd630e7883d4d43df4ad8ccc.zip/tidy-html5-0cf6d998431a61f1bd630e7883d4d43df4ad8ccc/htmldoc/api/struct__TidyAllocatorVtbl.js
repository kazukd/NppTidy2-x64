var struct__TidyAllocatorVtbl =
[
    [ "alloc", "struct__TidyAllocatorVtbl.html#ac89bb7f5b58fcb5b31a1560705f3b817", null ],
    [ "realloc", "struct__TidyAllocatorVtbl.html#a0cad0dd2aa75a20573fc46f25460a5cc", null ],
    [ "void", "struct__TidyAllocatorVtbl.html#a1e453d5e80b35fe3c6c15512c6b95aa5", null ],
    [ "void", "struct__TidyAllocatorVtbl.html#a4ecb749644f9253427eb53028363d01d", null ],
    [ "block", "struct__TidyAllocatorVtbl.html#a098a1144e7222917467b007f7a5001fc", null ],
    [ "msg", "struct__TidyAllocatorVtbl.html#a93b8f23e78a6636c055ecc9ff13aadb3", null ]
];