var struct__TidyOutputSink =
[
    [ "sinkData", "struct__TidyOutputSink.html#a8ea61dfa1ce4ba41a7a9c50b7729ab8a", null ],
    [ "putByte", "struct__TidyOutputSink.html#a0b392463d9767dc9fbed2f524fbe7407", null ]
];