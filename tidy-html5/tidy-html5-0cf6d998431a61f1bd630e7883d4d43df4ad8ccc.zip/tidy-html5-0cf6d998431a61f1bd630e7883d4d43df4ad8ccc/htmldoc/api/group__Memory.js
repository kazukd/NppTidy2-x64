var group__Memory =
[
    [ "_TidyAllocatorVtbl", "struct__TidyAllocatorVtbl.html", null ],
    [ "_TidyAllocator", "struct__TidyAllocator.html", null ],
    [ "TidyAllocatorVtbl", "group__Memory.html#ga3fe8c5ac7d658618c732565776940ed8", null ],
    [ "TidyAllocator", "group__Memory.html#ga78e96524a88db0c09e766795265863da", null ],
    [ "TidyMalloc", "group__Memory.html#ga3bd3cc4d0c837a4cd10ab472ba671430", null ],
    [ "TidyRealloc", "group__Memory.html#ga9d9a5625817932dbbb39dd33de678edd", null ],
    [ "TidyFree", "group__Memory.html#ga27931c443e424937ba47f0d4795aa35f", null ],
    [ "TidyPanic", "group__Memory.html#ga0770be41d9935a3e2933ba0be3c7725c", null ],
    [ "tidySetMallocCall", "group__Memory.html#gab55079374527525e3374ebc4d2a1e625", null ],
    [ "tidySetReallocCall", "group__Memory.html#ga446b538da3ee3f2e5a3827b877665b30", null ],
    [ "tidySetFreeCall", "group__Memory.html#ga70e707b7df86effb5727b0b9ff64eed7", null ],
    [ "tidySetPanicCall", "group__Memory.html#gab12cc0435bacec1a8c725e02357acc00", null ]
];