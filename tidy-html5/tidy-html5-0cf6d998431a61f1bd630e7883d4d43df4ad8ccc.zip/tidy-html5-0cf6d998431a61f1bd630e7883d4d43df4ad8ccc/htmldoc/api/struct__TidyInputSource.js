var struct__TidyInputSource =
[
    [ "sourceData", "struct__TidyInputSource.html#a19bd9d8877bfc702ceae4e174d0b07d4", null ],
    [ "getByte", "struct__TidyInputSource.html#a4c318270e25e2e4dd9506cb04542b7d8", null ],
    [ "ungetByte", "struct__TidyInputSource.html#a8bb61c749e1295207cd92752e63ae505", null ],
    [ "eof", "struct__TidyInputSource.html#af90ba85f6caffb1321a8fe3ef4b7bebb", null ]
];