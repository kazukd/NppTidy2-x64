var files =
[
    [ "buffio.h", "buffio_8h.html", "buffio_8h" ],
    [ "platform.h", null, null ],
    [ "tidy.h", "tidy_8h.html", "tidy_8h" ],
    [ "tidyenum.h", null, null ]
];