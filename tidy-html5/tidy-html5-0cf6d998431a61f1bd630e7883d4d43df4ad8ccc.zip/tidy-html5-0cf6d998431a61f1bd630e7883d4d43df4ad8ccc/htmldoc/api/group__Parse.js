var group__Parse =
[
    [ "tidyParseFile", "group__Parse.html#ga5ec263f2e430dd9c9e10437f067b2a28", null ],
    [ "tidyParseStdin", "group__Parse.html#ga96b41ff6e6a7f9d0b9b0e901e33ad31d", null ],
    [ "tidyParseString", "group__Parse.html#ga50c02fa244dcd120ae339719c2132ff9", null ],
    [ "tidyParseBuffer", "group__Parse.html#gaa28ce34c95750f150205843885317851", null ],
    [ "tidyParseSource", "group__Parse.html#gaa65dad2a4ca5fa97d267ddefe1180e0e", null ]
];