var group__Tree =
[
    [ "tidyGetRoot", "group__Tree.html#gac70f893c5cd5805bf76b393ad07c93c6", null ],
    [ "tidyGetHtml", "group__Tree.html#gae539f5031bd1e039458a7fffb07a2b7a", null ],
    [ "tidyGetHead", "group__Tree.html#ga8bc403902d8535a6dab3efc29519d970", null ],
    [ "tidyGetBody", "group__Tree.html#ga860430a9ae7b9d347f0f7eb4204b3046", null ],
    [ "tidyGetParent", "group__Tree.html#ga0da0a16a07321623bda6a02a397111ca", null ],
    [ "tidyGetChild", "group__Tree.html#ga0ef21eb446a56c3874a993b6f3966e73", null ],
    [ "tidyGetNext", "group__Tree.html#ga60f48e1a0981ccfa027e62f73f0b1e7d", null ],
    [ "tidyGetPrev", "group__Tree.html#ga7a277d67c8143a8dd66d6c4796e5afa2", null ],
    [ "tidyAttrFirst", "group__Tree.html#ga7247560b46127ac69780b938d8bca177", null ],
    [ "tidyAttrNext", "group__Tree.html#ga8af1c83f5c33e767ca40561341089bae", null ],
    [ "tidyAttrName", "group__Tree.html#ga32dff6f721a553a54cee0324cda15ba7", null ],
    [ "tidyAttrValue", "group__Tree.html#gaeb8f272e8135e744b9b3f006517f1073", null ]
];